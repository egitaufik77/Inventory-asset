<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
        $this->load->helper(array('url', 'form'));
    }

    public function index() {
        $data['users'] = $this->User_model->get_all_users();
        $this->load->view('header');
        $this->load->view('user_list', $data);
        $this->load->view('footer');
    }

    public function add() {
        if ($this->input->post()) {
            $data = array(
                'username' => $this->input->post('username'),
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'priviledge' => $this->input->post('priviledge')
            );
            $this->User_model->insert_user($data);
            redirect('user');
        } else {
            $this->load->view('header');
            $this->load->view('user_form');
            $this->load->view('footer');
        }
    }

    public function edit($username) {
        $data['user'] = $this->User_model->get_user($username);
        if (empty($data['user'])) {
            show_404();
        }

        if ($this->input->post()) {
            $update = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'priviledge' => $this->input->post('priviledge')
            );
            if (!empty($this->input->post('password'))) {
                $update['password'] = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
            }
            $this->User_model->update_user($username, $update);
            redirect('user');
        } else {
            $this->load->view('header');
            $this->load->view('user_form', $data);
            $this->load->view('footer');
        }
    }

    public function delete($username) {
        $this->User_model->delete_user($username);
        redirect('user');
    }
}
